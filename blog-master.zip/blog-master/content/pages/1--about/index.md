---
title: About
---
<re-img src="avatar-large.jpeg" hovereffect=true></re-img>

Hi there. I'm Atte Juvonen and this is my personal blog.
I ramble about code, data, and other geeky interests.
This blog is open sourced on [GitHub](https://www.github.com/baobabKoodaa/blog/),
feel free to submit corrections or use the code to create your own blog.

<re-icons></re-icons>