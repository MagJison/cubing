export { default } from "./Seo";
