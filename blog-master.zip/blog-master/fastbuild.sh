#!/bin/bash
gatsby build
gatsby serve
